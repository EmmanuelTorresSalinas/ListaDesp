---
name: 'Practice: Classes and Collections'
about: 'Issue for Practice: Classes and Collections'
title: 'Practice: Classes and Collections: Android Basics in Compose  '
labels: ''
assignees: ''

---

**URL of codelab**


**In which task and step of the codelab can this issue be found?**


**Describe the problem**




**Steps to reproduce?**
1. Go to...
2. Click on...
3. See error...

**Versions**
_Android Studio version:_ 
_API version of the emulator:_ 


**Additional information**
_Include screenshots if they would be useful in clarifying the problem._
